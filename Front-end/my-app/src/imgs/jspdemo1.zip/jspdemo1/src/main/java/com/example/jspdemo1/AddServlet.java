package com.example.jspdemo1;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class AddServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        int i = Integer.parseInt(request.getParameter("a"));
        int j = Integer.parseInt(request.getParameter("b"));
        int k = i + j;
//        response.getWriter().println("Result is:" + k);
//        System.out.println("Result is:" + k);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("sq");
        requestDispatcher.forward(request, response);
    }
}
